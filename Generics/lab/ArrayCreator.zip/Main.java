//package Generics.lab;

public class Main {
}
