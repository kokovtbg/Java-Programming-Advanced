package IteratorsComparatos.exercise;

public class ComparingObjects {
    private String name;
    private int age;
    private String town;

    public ComparingObjects(String name, int age, String town) {
        this.name = name;
        this.age = age;
        this.town = town;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getTown() {
        return town;
    }
}
